/**
 * 
 */

function myProfile(){
	document.getElementById("main-panel").style.display="none";
	document.getElementById("issueBook").style.display="none";
	document.getElementById("col-12 grid-margin stretch-card").style.display="block";
}

function myDashboard(){
	document.getElementById("main-panel").style.display="block";
	document.getElementById("issueBook").style.display="none";
	document.getElementById("col-12 grid-margin stretch-card").style.display="none";
}




