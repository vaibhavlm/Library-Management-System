
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class details
 */
@WebServlet("/details")
public class details extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public details() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String email=(String) session.getAttribute("mail");
		String name = request.getParameter("username");
		String dob = request.getParameter("dob").toString();
		String gender = request.getParameter("gender");
		long phone_number = Long.parseLong(request.getParameter("ph"));
		String mail = request.getParameter("mail").toLowerCase();
		String address = request.getParameter("address");
		String state = request.getParameter("state");
		String country = request.getParameter("country");
		PrintWriter out = response.getWriter();
		try {
			java.util.Date date_of_birth = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
			java.sql.Date mySqlDate = new java.sql.Date(date_of_birth.getTime());
			Connection con = DB.getConnection();
			PreparedStatement ps1=con.prepareStatement("select * from USERCREDENTIALS where email=?");
	        ps1.setString(1,mail);
	        ResultSet rs = ps1.executeQuery();
	        if(rs.next()&&mail.equals(email)) {
				PreparedStatement ps = con.prepareStatement(
						"update USERCREDENTIALS set name=?,DATE_OF_BIRTH=?,gender=?,ADDRESS=?,STATE=?,COUNTRY=?,PHONE_NUMBER=? where email=?");
				ps.setString(1,name);
				ps.setDate(2,mySqlDate);
				ps.setString(3,gender);
				ps.setString(4,address);
				ps.setString(5,state);
				ps.setString(6,country);
				ps.setLong(7,phone_number);
				ps.setString(8, mail);
				ps.execute();
				con.close();
				out.println("<script>");
				out.println("alert('Profile Details Uploaded Successfully!, Please logout and login again to see the changes');");
				out.println("location='portal.jsp';");
				out.println("</script>");
			}
	        else {
				out.println("<script>");
				out.println("alert('Profile Details are not uploaded, Please try again after sometime!');");
				out.println("location='portal.jsp';");
				out.println("</script>");
	        }
		} catch (Exception e) {
			System.out.println(e);
		}
		// doGet(request, response);
	}

}
