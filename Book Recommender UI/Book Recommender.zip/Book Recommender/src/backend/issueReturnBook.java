package backend;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class issueReturnBook
 */
@WebServlet("/issueReturnBook")
public class issueReturnBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public issueReturnBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String email=(String) session.getAttribute("mail");
		String name=(String) session.getAttribute("name");
		String book_name=request.getParameter("Bookname");
		String IssueDate = request.getParameter("IssueDate").toString();
		String ReturnDate = request.getParameter("ReturnDate").toString();
		PrintWriter out = response.getWriter();
		try {
			java.util.Date return_date = new SimpleDateFormat("yyyy-MM-dd").parse(ReturnDate);
			java.util.Date issue_date = new SimpleDateFormat("yyyy-MM-dd").parse(IssueDate);
			java.sql.Date Sql_IssueDate = new java.sql.Date(issue_date.getTime());
			java.sql.Date Sql_ReturnDate = new java.sql.Date(return_date.getTime());
			
			Connection con = DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into ISSUE_RETURN_BOOK(NAME,BOOK_NAME,DATE_OF_ISSUE,DATE_OF_RETURN,EMAIL) values(?,?,?,?,?)");
			ps.setString(1, name);
			ps.setString(2, book_name);
			ps.setDate(3, Sql_IssueDate);
			ps.setDate(4, Sql_ReturnDate);
			ps.setString(5, email);
			ps.execute();
			con.close();
			out.println("<script>");
			out.println("alert('Details saved successfully!');");
			out.println("location='portal.jsp';");
			out.println("</script>");
		}
		catch(Exception e) {
			System.out.println(e);
		}
		//doGet(request, response);
	}

}
