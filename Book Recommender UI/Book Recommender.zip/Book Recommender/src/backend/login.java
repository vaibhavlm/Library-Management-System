package backend;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html"); 
		String login_mail=request.getParameter("lmail").toLowerCase();
		String login_psw=request.getParameter("lpsw");
		PrintWriter out = response.getWriter();
        try
		{
        	String destPage = "userlogin.jsp";
        	Connection con=DB.getConnection();
        	PreparedStatement ps=con.prepareStatement("select * from USERCREDENTIALS where email=? and password=?");
	        ps.setString(1,login_mail);
	        ps.setString(2,login_psw);
            ResultSet rs = ps.executeQuery();
	        if(rs.next()) {
	        	HttpSession session = request.getSession();
                session.setAttribute("mail", login_mail);
                session.setAttribute("name", rs.getString(1));
                destPage = "portal.jsp";
		    }
	        else
	        	request.setAttribute("error", "Incorrect username or password");
	        RequestDispatcher rd=request.getRequestDispatcher(destPage);
	        rd.forward(request, response);
	    
	        con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//doGet(request, response);
	}

}
